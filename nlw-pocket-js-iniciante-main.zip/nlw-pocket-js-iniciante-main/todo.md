[x] Criar metas
[x] Listar metas
    [x] Metas realizadas
    [x] Metas abertas
[x] Marcar/Desmarcar metas realizadas
[x] Remover metas
[x] Sistema de mensages
[x] Persistir dados
